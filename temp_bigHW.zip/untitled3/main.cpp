#include <QApplication>
#include <QMainWindow>
#include <QTextEdit>
#include <QTextCursor>
#include <QTextCharFormat>
#include <QDebug>
#include <QFile>
#include "Statement.h"
#include <iostream>
#include <QTextStream>
#include <QDir>
#include <stdio.h>
#include <QString>
#include <QDataStream>

using namespace std;
map<string,int> Map;
bool OK=0;

bool isvaild(string content){

    Lexer lexer;lexer.nowpos=0;
    lexer.s=content;lexer.length=content.size();

  //  cout<<lexer.s<<" "<<lexer.length<<endl;
    lexer.las = lexer.Getnextchar();
  //  cout<<"!"<<lexer.las<<endl;
    OK=true;
    while (lexer.las != EOF) {
        lexer.GetNextToken();
        Token tk = lexer.GetCurToken();
        if(tk.type==GG) return 0;
        if (tk.s != "output") {
            lexer.GetNextToken();
            Token tk2 = lexer.GetCurToken();
            if (tk2.s == "=") {
                Assignment(tk.s).execute(lexer);
            } else {
                cout << "error for unknown statement" << endl;
                return true;
            }
        } else {
            Output().execute(lexer);
        }

    }
    return !OK;
}

class TextEditor : public QMainWindow {
public:
    TextEditor(QWidget *parent = nullptr) : QMainWindow(parent) {
        textEdit = new QTextEdit(this);
        textEdit->setFontPointSize(22);
        setCentralWidget(textEdit);

        connect(textEdit, &QTextEdit::textChanged, this, &TextEditor::highlightLines);
    }

private slots:
    void highlightLines() {
        textEdit->setFontPointSize(22);
        Map.clear();
        QString text = textEdit->toPlainText();
        QTextCursor cursor(textEdit->document());

        QList<QTextEdit::ExtraSelection> extraSelections;
        while (!cursor.atEnd()) {
            cursor.select(QTextCursor::LineUnderCursor);
            QString line = cursor.selectedText();
            string content = line.toStdString();

            if (isvaild(content)) {
                QTextEdit::ExtraSelection selection;
                selection.format.setBackground(Qt::red);
                selection.cursor = cursor;
                extraSelections.append(selection);
            }

            cursor.movePosition(QTextCursor::NextBlock);
        }

        textEdit->setExtraSelections(extraSelections);
    }

private:
    QTextEdit *textEdit;
};

int main(int argc, char *argv[]) {
    //Lexer S;
    QApplication app(argc, argv);

    TextEditor editor;
    editor.resize(800, 600);
    editor.show();

    return app.exec();
}
/*
x=x+2
output x
*/
